// server.js
const express = require('express')
const http = require('http')
const { Server } = require('socket.io')
const path = require('path')
const multer = require('multer')
const cors = require('cors')
const fs = require('fs')

// --------------------
// Проверка и создание папки для загрузок
// --------------------
const uploadDir = path.join(__dirname, 'uploads')
if (!fs.existsSync(uploadDir)) {
	fs.mkdirSync(uploadDir)
	console.log('Папка "uploads" создана.')
}

// --------------------
// Настройка Multer (для загрузки файлов/аватарок/аудио)
// --------------------
const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'uploads/')
	},
	filename: function (req, file, cb) {
		const uniqueName = Date.now() + '-' + file.originalname
		cb(null, uniqueName)
	},
})
const upload = multer({ storage })

// --------------------
// Создаём приложение
// --------------------
const app = express()
const server = http.createServer(app)
const io = new Server(server)

// Миддлвары
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

const users = {}
users['admin'] = {
	username: 'admin',
	password: '12345', // В реальном приложении используйте хеширование паролей
	avatarUrl: null,
	isAdmin: true,
	isBanned: false,
	isMuted: false,
	isOnline: false,
	socketId: null,
}

// --------------------
// Флаг «сайт отключен» (для всех кроме админа)
// --------------------
let siteDisabledForAllExceptAdmin = false

let chatMessages = [] // общий чат

const directMessages = new Map() // key = "userA|userB", value = array of messages

const groups = {}
let groupCounter = 1 // счётчик для генерирования groupId

app.use(express.static(path.join(__dirname, 'public')))
app.use('/uploads', express.static(path.join(__dirname, 'uploads')))

app.post('/register', (req, res) => {
	const { username, password } = req.body
	if (!username || !password) {
		return res
			.status(400)
			.json({ message: 'Необходимо корректно заполнить поля!' })
	}
	if (users[username]) {
		return res.status(400).json({ message: 'Пользователь уже существует' })
	}
	users[username] = {
		username,
		password,
		avatarUrl: null,
		isAdmin: false,
		isBanned: false,
		isMuted: false,
		isOnline: false,
		socketId: null,
	}
	console.log(`Пользователь зарегистрирован: ${username}`)
	return res.json({ message: 'Регистрация прошла успешно' })
})

app.post('/login', (req, res) => {
	const { username, password } = req.body
	const user = users[username]
	if (!user) {
		return res.status(401).json({ message: 'Неверные учётные данные' })
	}
	if (user.password !== password) {
		return res.status(401).json({ message: 'Неверные учётные данные' })
	}
	if (user.isBanned) {
		return res.status(403).json({ message: 'Вы забанены' })
	}
	user.isOnline = true
	console.log(`Пользователь вошёл в систему: ${username}`)
	return res.json({
		message: 'Успешный вход',
		username: user.username,
		isAdmin: user.isAdmin,
		avatarUrl: user.avatarUrl || '',
	})
})

app.post('/profile/edit', (req, res) => {
	const { username, oldPassword, newPassword } = req.body
	if (!username || !oldPassword || !newPassword) {
		return res.status(400).json({ message: 'Необходимо заполнить все поля' })
	}
	const user = users[username]
	if (!user) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	if (user.password !== oldPassword) {
		return res.status(401).json({ message: 'Неверный пароль' })
	}
	user.password = newPassword
	console.log(`Пользователь обновил пароль: ${username}`)
	return res.json({ message: 'Пароль успешно обновлён' })
})

app.post('/profile/avatar', upload.single('avatar'), (req, res) => {
	const { username, password } = req.body
	if (!username || !password) {
		return res.status(400).json({ message: 'Необходимо заполнить все поля' })
	}
	const user = users[username]
	if (!user) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	if (user.password !== password) {
		return res.status(401).json({ message: 'Неверный пароль' })
	}
	if (!req.file) {
		return res.status(400).json({ message: 'Файл не получен' })
	}
	user.avatarUrl = `/uploads/${req.file.filename}`
	console.log(`Пользователь обновил аватар: ${username}`)
	return res.json({
		message: 'Аватар успешно обновлён',
		avatarUrl: user.avatarUrl,
	})
})

function checkAdmin(req, res, next) {
	const { adminUsername } = req.body
	if (
		!adminUsername ||
		!users[adminUsername] ||
		!users[adminUsername].isAdmin
	) {
		return res.status(403).json({ message: 'Доступ только для админа' })
	}
	next()
}

app.post('/admin/mute', checkAdmin, (req, res) => {
	const { targetUsername } = req.body
	if (!targetUsername) {
		return res.status(400).json({ message: 'Необходимо указать пользователя' })
	}
	if (!users[targetUsername]) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	users[targetUsername].isMuted = true
	sendSystemMessage(
		`Пользователь ${targetUsername} замьючен администратором`,
		null
	)
	console.log(`Админ замьючил пользователя: ${targetUsername}`)
	return res.json({ message: `Пользователь ${targetUsername} замьючен` })
})

app.post('/admin/unmute', checkAdmin, (req, res) => {
	const { targetUsername } = req.body
	if (!targetUsername) {
		return res.status(400).json({ message: 'Необходимо указать пользователя' })
	}
	if (!users[targetUsername]) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	users[targetUsername].isMuted = false
	sendSystemMessage(
		`Пользователь ${targetUsername} размьючен администратором`,
		null
	)
	console.log(`Админ размьючил пользователя: ${targetUsername}`)
	return res.json({ message: `Пользователь ${targetUsername} размьючен` })
})

app.post('/admin/ban', checkAdmin, (req, res) => {
	const { targetUsername } = req.body
	if (!targetUsername) {
		return res.status(400).json({ message: 'Необходимо указать пользователя' })
	}
	if (!users[targetUsername]) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	users[targetUsername].isBanned = true

	if (users[targetUsername].socketId) {
		const sock = io.sockets.sockets.get(users[targetUsername].socketId)
		if (sock) {
			sock.emit('errorMsg', 'Вы забанены (admin)')
			sock.disconnect(true)
		}
	}
	sendSystemMessage(
		`Пользователь ${targetUsername} забанен администратором`,
		null
	)
	console.log(`Админ забанил пользователя: ${targetUsername}`)
	return res.json({ message: `Пользователь ${targetUsername} забанен` })
})

app.post('/admin/unban', checkAdmin, (req, res) => {
	const { targetUsername } = req.body
	if (!targetUsername) {
		return res.status(400).json({ message: 'Необходимо указать пользователя' })
	}
	if (!users[targetUsername]) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	users[targetUsername].isBanned = false
	sendSystemMessage(
		`Пользователь ${targetUsername} разбанен администратором`,
		null
	)
	console.log(`Админ разбанил пользователя: ${targetUsername}`)
	return res.json({ message: `Пользователь ${targetUsername} разбанен` })
})

app.post('/admin/kick', checkAdmin, (req, res) => {
	const { targetUsername } = req.body
	if (!targetUsername) {
		return res.status(400).json({ message: 'Необходимо указать пользователя' })
	}
	if (!users[targetUsername]) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	if (users[targetUsername].socketId) {
		const sock = io.sockets.sockets.get(users[targetUsername].socketId)
		if (sock) {
			sock.emit('errorMsg', 'Вас кикнул глобальный админ')
			sock.disconnect(true)
		}
	}
	sendSystemMessage(
		`Пользователь ${targetUsername} кикнут администратором`,
		null
	)
	console.log(`Админ кикнул пользователя: ${targetUsername}`)
	return res.json({ message: `Пользователь ${targetUsername} кикнут` })
})

app.post('/admin/delete', checkAdmin, (req, res) => {
	const { targetUsername } = req.body
	if (!targetUsername) {
		return res.status(400).json({ message: 'Необходимо указать пользователя' })
	}
	if (!users[targetUsername]) {
		return res.status(404).json({ message: 'Пользователь не найден' })
	}
	if (users[targetUsername].socketId) {
		const sock = io.sockets.sockets.get(users[targetUsername].socketId)
		if (sock) {
			sock.emit('errorMsg', 'Ваш аккаунт удалён администратором')
			sock.disconnect(true)
		}
	}
	delete users[targetUsername]
	sendSystemMessage(`Аккаунт ${targetUsername} удалён администратором`, null)
	console.log(`Админ удалил пользователя: ${targetUsername}`)
	return res.json({ message: `Пользователь ${targetUsername} удалён` })
})

app.post('/admin/toggle-site', checkAdmin, (req, res) => {
	siteDisabledForAllExceptAdmin = !siteDisabledForAllExceptAdmin
	const msg = siteDisabledForAllExceptAdmin
		? 'Сайт отключен для всех, кроме админа'
		: 'Сайт снова включён для всех'
	sendSystemMessage(msg, null)
	console.log(`Админ изменил статус сайта: ${msg}`)
	return res.json({ message: msg })
})

app.get('/users/list', (req, res) => {
	const all = Object.keys(users)
	return res.json(all)
})

app.post('/api/upload', upload.single('file'), (req, res) => {
	if (!req.file) {
		return res.status(400).json({ message: 'Файл не получен' })
	}
	console.log(`Файл загружен: ${req.file.filename}`)
	return res.json({ fileUrl: `/uploads/${req.file.filename}` })
})

app.post('/groups/create', (req, res) => {
	const { username, groupName } = req.body
	if (!username || !groupName) {
		return res
			.status(400)
			.json({ message: 'Необходимо указать пользователя и название группы' })
	}
	if (!users[username])
		return res.status(404).json({ message: 'Пользователь не найден' })
	if (users[username].isBanned)
		return res.status(403).json({ message: 'Вы забанены' })
	if (!groupName)
		return res
			.status(400)
			.json({ message: 'Название группы не может быть пустым' })

	const groupId = `group-${groupCounter++}`
	groups[groupId] = {
		id: groupId,
		name: groupName,
		owner: username,
		members: new Set([username]),
		messages: [],
	}

	sendSystemMessage(
		`Создана группа "${groupName}" (id=${groupId}), владелец: ${username}`,
		groupId
	)
	console.log(`Группа создана: ${groupName} (ID: ${groupId})`)
	return res.json({ message: 'Группа создана', groupId })
})

app.post('/groups/invite', (req, res) => {
	const { groupId, fromUsername, toUsername } = req.body
	if (!groupId || !fromUsername || !toUsername) {
		return res
			.status(400)
			.json({ message: 'Необходимо указать группу, отправителя и получателя' })
	}
	const group = groups[groupId]
	if (!group) return res.status(404).json({ message: 'Группа не найдена' })
	if (!users[toUsername])
		return res.status(404).json({ message: 'Нет такого пользователя' })

	if (group.owner !== fromUsername && !users[fromUsername].isAdmin) {
		return res.status(403).json({ message: 'Нет прав приглашать' })
	}

	group.members.add(toUsername)
	group.messages.push({
		from: 'SYSTEM',
		text: `Пользователь ${toUsername} приглашён в группу`,
		time: new Date().toISOString(),
	})
	sendSystemMessage(
		`Пользователь ${toUsername} приглашён в группу ${group.name}`,
		groupId
	)
	console.log(`Пользователь ${toUsername} приглашён в группу ${groupId}`)
	return res.json({
		message: `Пользователь ${toUsername} добавлен в группу ${groupId}`,
	})
})

app.post('/groups/kick', (req, res) => {
	const { groupId, fromUsername, targetUsername } = req.body
	if (!groupId || !fromUsername || !targetUsername) {
		return res.status(400).json({
			message: 'Необходимо указать группу, отправителя и целевого пользователя',
		})
	}
	const group = groups[groupId]
	if (!group) return res.status(404).json({ message: 'Группа не найдена' })
	if (!users[targetUsername])
		return res.status(404).json({ message: 'Нет такого пользователя' })
	if (group.owner !== fromUsername && !users[fromUsername].isAdmin) {
		return res.status(403).json({ message: 'Нет прав кикать' })
	}
	if (!group.members.has(targetUsername)) {
		return res.status(400).json({ message: 'Такого участника нет в группе' })
	}
	group.members.delete(targetUsername)
	group.messages.push({
		from: 'SYSTEM',
		text: `Пользователь ${targetUsername} кикнут`,
		time: new Date().toISOString(),
	})

	if (users[targetUsername].socketId) {
		const sock = io.sockets.sockets.get(users[targetUsername].socketId)
		if (sock) {
			sock.emit('errorMsg', `Вас кикнули из группы ${group.name}`)
		}
	}
	sendSystemMessage(
		`Пользователь ${targetUsername} кикнут из группы ${group.name}`,
		groupId
	)
	console.log(`Пользователь ${targetUsername} кикнут из группы ${groupId}`)
	return res.json({
		message: `Пользователь ${targetUsername} кикнут из группы ${groupId}`,
	})
})

app.get('/groups/all', (req, res) => {
	const arr = Object.values(groups).map(g => ({
		id: g.id,
		name: g.name,
		owner: g.owner,
		members: Array.from(g.members),
	}))
	return res.json(arr)
})

io.on('connection', socket => {
	console.log('New client connected:', socket.id)

	const { username } = socket.handshake.query
	console.log('Username from query:', username)
	if (!username || !users[username]) {
		socket.emit('errorMsg', 'Неизвестный пользователь')
		socket.disconnect(true)
		return
	}

	const user = users[username]
	if (user.isBanned) {
		socket.emit('errorMsg', 'Вы забанены')
		socket.disconnect(true)
		return
	}
	if (siteDisabledForAllExceptAdmin && !user.isAdmin) {
		socket.emit('errorMsg', 'Сайт отключен администратором')
		socket.disconnect(true)
		return
	}

	user.socketId = socket.id
	user.isOnline = true
	sendSystemMessage(`${username} присоединился к чату`, null)
	console.log(`Пользователь онлайн: ${username}`)

	socket.emit('chatHistory', chatMessages)

	socket.on('chatMessage', data => {
		if (user.isMuted) {
			socket.emit('errorMsg', 'Вы получили мут! Сообщения не доставлены.')
			return
		}
		const msgObj = {
			from: username,
			avatarUrl: user.avatarUrl || '',
			text: data.text || '',
			fileUrl: data.fileUrl || '',
			time: new Date().toISOString(),
		}
		chatMessages.push(msgObj)
		io.emit('chatMessage', msgObj)
	})

	socket.on('privateMessage', data => {
		const toUser = data.to
		if (!toUser || !users[toUser]) {
			socket.emit('errorMsg', 'Пользователь не найден для ЛС')
			return
		}
		if (user.isMuted) {
			socket.emit('errorMsg', 'Вы в муте!')
			return
		}
		if (user.isBanned) {
			socket.emit('errorMsg', 'Вы забанены!')
			return
		}
		const msgObj = {
			from: username,
			to: toUser,
			avatarUrl: user.avatarUrl || '',
			text: data.text || '',
			fileUrl: data.fileUrl || '',
			time: new Date().toISOString(),
		}
		const key = makeConvoKey(username, toUser)
		if (!directMessages.has(key)) directMessages.set(key, [])
		directMessages.get(key).push(msgObj)

		socket.emit('privateMessage', msgObj)

		const targetSock = users[toUser].socketId
		if (targetSock) {
			io.to(targetSock).emit('privateMessage', msgObj)
		}
		console.log(`Личное сообщение от ${username} к ${toUser}: ${data.text}`)
	})

	socket.on('requestDMHistory', (data, callback) => {
		const { userA, userB } = data
		const key = makeConvoKey(userA, userB)
		const dmHistory = directMessages.get(key) || []
		callback({ dmHistory })
	})

	socket.on('groupMessage', data => {
		const { groupId, text, fileUrl } = data
		const group = groups[groupId]
		if (!group) {
			socket.emit('errorMsg', 'Нет такой группы')
			return
		}
		if (!group.members.has(username) && !user.isAdmin) {
			socket.emit('errorMsg', 'Вы не состоите в этой группе')
			return
		}
		if (user.isMuted) {
			socket.emit('errorMsg', 'Вы замьючены (глобально)')
			return
		}
		const msgObj = {
			from: username,
			avatarUrl: user.avatarUrl || '',
			text: text || '',
			fileUrl: fileUrl || '',
			time: new Date().toISOString(),
		}
		group.messages.push(msgObj)

		group.members.forEach(mName => {
			const mUser = users[mName]
			if (mUser && mUser.socketId) {
				io.to(mUser.socketId).emit('groupMessage', { groupId, ...msgObj })
			}
		})
		console.log(
			`Групповое сообщение от ${username} в группу ${groupId}: ${text}`
		)
	})

	socket.on('requestGroupHistory', (data, callback) => {
		const { groupId } = data
		const group = groups[groupId]
		if (!group) {
			return callback({ error: 'Группа не найдена' })
		}
		if (!group.members.has(username) && !user.isAdmin) {
			return callback({ error: 'Вы не состоите в группе' })
		}
		callback({ history: group.messages })
	})

	socket.on('disconnect', () => {
		user.socketId = null
		user.isOnline = false
		sendSystemMessage(`${username} вышел из чата`, null)
		console.log(`Пользователь оффлайн: ${username}`)
	})
})

function makeConvoKey(a, b) {
	const sorted = [a, b].sort()
	return sorted.join('|')
}

function sendSystemMessage(text, groupId) {
	const time = new Date().toISOString()
	if (!groupId) {
		const msgObj = { from: 'SYSTEM', text, time }
		chatMessages.push(msgObj)
		io.emit('chatMessage', msgObj)
	} else {
		const group = groups[groupId]
		if (group) {
			const msgObj = { from: 'SYSTEM', text, time }
			group.messages.push(msgObj)
			group.members.forEach(mName => {
				const sockId = users[mName]?.socketId
				if (sockId) {
					io.to(sockId).emit('groupMessage', { groupId, ...msgObj })
				}
			})
		}
	}
}

const PORT = 3000
server.listen(PORT, () => {
	console.log('Server started on port', PORT)
})
