/************************************************
 * chat.js
 ************************************************/

// Получаем из localStorage: имя пользователя (currentUsername) и признак админа (isAdmin)
const currentUsername = localStorage.getItem('currentUsername') || ''
const isAdmin = localStorage.getItem('isAdmin') === 'true'

// Если пользователь не авторизован — перенаправляем на логин
if (!currentUsername) {
	alert('Сначала войдите')
	window.location.href = '/login.html'
}

// DOM-элементы
const chatWindow = document.getElementById('chatWindow')
const messageForm = document.getElementById('messageForm')
const messageInput = document.getElementById('messageInput')
const fileInput = document.getElementById('fileInput')

const dmBtn = document.getElementById('dmBtn')
const groupsBtn = document.getElementById('groupsBtn')
const adminPanelBtn = document.getElementById('adminPanelBtn')

// Голосовые
const startRecordBtn = document.getElementById('startRecordBtn')
const stopRecordBtn = document.getElementById('stopRecordBtn')
let mediaRecorder = null
let audioChunks = []

// Стикеры
const stickersBtn = document.getElementById('stickersBtn')
const stickersPanel = document.getElementById('stickersPanel')
const stickerElems = document.querySelectorAll('.sticker')

// Переходы на другие страницы
dmBtn.addEventListener('click', () => {
	window.location.href = '/dm.html'
})
groupsBtn.addEventListener('click', () => {
	window.location.href = '/groups.html'
})
adminPanelBtn.addEventListener('click', () => {
	window.location.href = '/admin.html'
})
adminPanelBtn.style.display = isAdmin ? 'block' : 'none' // Показывать только админам

// Инициализация сокета (Socket.IO)
const socket = io({
	query: {
		username: currentUsername,
	},
})

socket.on('connect', () => {
	console.log('Подключен к серверу (глобальный чат)')
})

socket.on('disconnect', () => {
	console.log('Отключено от сервера (глобальный чат)')
})

socket.on('errorMsg', msg => {
	alert(msg)
})

// При загрузке получаем историю чата
socket.on('chatHistory', history => {
	chatWindow.innerHTML = ''
	// Для отладки:
	console.log('История:', history)
	history.forEach(msg => {
		addChatMessage(msg)
	})
})

// Получаем новое сообщение
socket.on('chatMessage', msg => {
	// Для отладки, смотрим, приходит ли time
	console.log('Новое сообщение:', msg)
	addChatMessage(msg)
})

// Личные сообщения (пример — просто alert)
socket.on('privateMessage', msg => {
	alert(`ЛС от ${msg.from}: ${msg.text}`)
})

// Отправка сообщений (текст + файл)
messageForm.addEventListener('submit', async e => {
	e.preventDefault()

	const text = messageInput.value.trim()
	let fileUrl = ''

	// Если прикреплён файл
	if (fileInput.files && fileInput.files.length > 0) {
		const formData = new FormData()
		formData.append('file', fileInput.files[0])

		try {
			// Отправляем файл на сервер (пример: /api/upload)
			const upRes = await fetch('/api/upload', {
				method: 'POST',
				body: formData,
			})
			const upData = await upRes.json()
			fileUrl = upData.fileUrl || ''
			fileInput.value = ''
		} catch (error) {
			console.error('Ошибка при загрузке файла:', error)
			alert('Не удалось загрузить файл')
			return
		}
	}

	// Отправляем событие 'chatMessage' на сервер
	socket.emit('chatMessage', {
		text,
		fileUrl,
		// Добавляем текущее время (ISO) на клиенте
		time: new Date().toISOString(),
	})

	// Очищаем поле ввода
	messageInput.value = ''
})

/************************************************
 * Функция форматирования времени «под Telegram»
 * например, "14:05"
 ************************************************/
function formatTelegramTime(isoString) {
	if (!isoString) return '' // Если время отсутствует
	const dateObj = new Date(isoString)
	if (isNaN(dateObj.getTime())) return '' // Если дата некорректна

	const hours = String(dateObj.getHours()).padStart(2, '0')
	const minutes = String(dateObj.getMinutes()).padStart(2, '0')
	return `${hours}:${minutes}`
}

/************************************************
 * Функция добавления сообщения в окно чата
 * msg = { from, text, fileUrl, time, avatarUrl }
 ************************************************/
function addChatMessage(msg) {
	// Создаём «пузырёк»
	const messageDiv = document.createElement('div')
	messageDiv.classList.add('chat-message')

	// Определяем, кто отправил:
	if (msg.from === 'SYSTEM') {
		// Системное сообщение
		messageDiv.classList.add('system')
		messageDiv.style.backgroundColor = '#e2e3e5' // Немного отличающийся цвет для системных сообщений
		messageDiv.style.alignSelf = 'center'
	} else if (msg.from === currentUsername) {
		// Ваше сообщение
		messageDiv.classList.add('self')
	} else {
		// Чужое сообщение
		messageDiv.classList.add('other')
	}

	// Обёртка для контента (текст + медиа)
	const contentWrapper = document.createElement('div')
	contentWrapper.style.display = 'flex'
	contentWrapper.style.flexDirection = 'column'

	// Определяем текст отправителя
	let whoLabel = ''
	if (msg.from === 'SYSTEM') {
		whoLabel = 'СИСТЕМА'
	} else if (msg.from === currentUsername) {
		whoLabel = 'Вы'
	} else {
		whoLabel = msg.from || '???'
	}

	// Форматируем время (а-ля Telegram)
	let timeStr = ''
	if (msg.time) {
		timeStr = formatTelegramTime(msg.time)
	} else {
		// Если time отсутствует, используем текущее время клиента
		timeStr = formatTelegramTime(new Date().toISOString())
	}

	// Создаём блок для текста
	const textEl = document.createElement('p')
	textEl.style.margin = '0'
	textEl.style.wordWrap = 'break-word'

	// Заполняем текст
	if (msg.from === 'SYSTEM') {
		// Системное сообщение
		textEl.innerHTML = `<em>СИСТЕМА:</em> ${msg.text || ''}`
	} else {
		if (msg.text) {
			textEl.innerHTML = `<strong>${whoLabel}</strong>: ${msg.text}`
		} else {
			// Если текст пустой (например, только файл/стикер)
			if (msg.from !== 'SYSTEM') {
				textEl.innerHTML = `<strong>${whoLabel}</strong>`
			}
		}
	}

	// Добавляем текстовый элемент к содержимому
	contentWrapper.appendChild(textEl)

	// Если есть fileUrl => обрабатываем как картинку/видео/аудио/ссылку
	if (msg.fileUrl) {
		const lower = msg.fileUrl.toLowerCase()

		if (/\.(png|jpg|jpeg|gif)$/i.test(lower)) {
			// Изображение/стикер
			messageDiv.classList.add('sticker-message')

			const imgEl = document.createElement('img')
			imgEl.src = msg.fileUrl
			imgEl.alt = 'Sticker'
			contentWrapper.appendChild(imgEl)
		} else if (/\.(mp4|webm)$/i.test(lower)) {
			// Видео
			const videoEl = document.createElement('video')
			videoEl.src = msg.fileUrl
			videoEl.controls = true
			videoEl.style.maxWidth = '200px'
			contentWrapper.appendChild(videoEl)
		} else if (/\.(ogg|mp3|wav)$/i.test(lower)) {
			// Аудио
			const audioEl = document.createElement('audio')
			audioEl.src = msg.fileUrl
			audioEl.controls = true
			contentWrapper.appendChild(audioEl)
		} else {
			// Прочие типы (PDF, ZIP, DOCX...) — обычная ссылка
			const linkEl = document.createElement('a')
			linkEl.href = msg.fileUrl
			linkEl.target = '_blank'
			linkEl.textContent = 'Скачать файл'
			contentWrapper.appendChild(linkEl)
		}
	}

	// Добавляем блок для времени
	if (timeStr) {
		const timeSpan = document.createElement('span')
		timeSpan.classList.add('message-time')
		timeSpan.textContent = timeStr
		contentWrapper.appendChild(timeSpan)
	}

	// Вкладываем весь контент внутрь «пузырька»
	messageDiv.appendChild(contentWrapper)

	// Добавляем сообщение в чат
	chatWindow.appendChild(messageDiv)

	// Скролл вниз
	chatWindow.scrollTop = chatWindow.scrollHeight
}

/************************************************
 * Голосовые сообщения
 ************************************************/
startRecordBtn.addEventListener('click', async () => {
	try {
		const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
		mediaRecorder = new MediaRecorder(stream)

		mediaRecorder.ondataavailable = e => {
			if (e.data.size > 0) {
				audioChunks.push(e.data)
			}
		}

		mediaRecorder.onstop = async () => {
			const audioBlob = new Blob(audioChunks, {
				type: 'audio/ogg; codecs=opus',
			})
			audioChunks = []

			try {
				// Загружаем на сервер
				const formData = new FormData()
				formData.append('file', audioBlob, 'voice.ogg')
				const resp = await fetch('/api/upload', {
					method: 'POST',
					body: formData,
				})
				const data = await resp.json()
				const fileUrl = data.fileUrl || ''

				// Отправляем как обычное сообщение (без текста)
				socket.emit('chatMessage', {
					text: '',
					fileUrl,
					time: new Date().toISOString(),
				})
			} catch (error) {
				console.error('Ошибка при загрузке аудио:', error)
				alert('Не удалось загрузить голосовое сообщение')
			}
		}

		mediaRecorder.start()
		startRecordBtn.disabled = true
		stopRecordBtn.disabled = false
	} catch (err) {
		alert('Не удалось получить доступ к микрофону')
		console.error(err)
	}
})

stopRecordBtn.addEventListener('click', () => {
	if (mediaRecorder && mediaRecorder.state !== 'inactive') {
		mediaRecorder.stop()
		startRecordBtn.disabled = false
		stopRecordBtn.disabled = true
	}
})

/************************************************
 * Стикеры
 ************************************************/
stickersBtn.addEventListener('click', () => {
	if (stickersPanel.style.display === 'block') {
		stickersPanel.style.display = 'none'
	} else {
		// Закрываем панель, если кликнули вне её
		document.addEventListener(
			'click',
			function handler(event) {
				if (
					!stickersPanel.contains(event.target) &&
					event.target !== stickersBtn
				) {
					stickersPanel.style.display = 'none'
					document.removeEventListener('click', handler)
				}
			},
			{ once: true }
		)
		stickersPanel.style.display = 'block'
	}
})

stickerElems.forEach(img => {
	img.addEventListener('click', () => {
		const stickerUrl = img.src
		// Отправляем стикер как файл
		socket.emit('chatMessage', {
			text: '',
			fileUrl: stickerUrl,
			time: new Date().toISOString(),
		})
		stickersPanel.style.display = 'none'
	})
})
